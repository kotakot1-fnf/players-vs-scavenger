package meow.binary.scavenger.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import meow.binary.scavenger.Scavenger;
import meow.binary.scavenger.data.modifier.ScavengerModifier;
import meow.binary.scavenger.registry.Modifiers;
import net.minecraft.core.UUIDUtil;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class ScavengerSavedData extends SavedData {
    private static final String DATA_NAME = "scavenger_data";
    private static final int CURRENT_DATA_VERSION = 1;

    private static final List<PreLoadMigration> PRE_LOAD_MIGRATIONS = List.of(
            ScavengerSavedData::migrate_v0_to_v1
    );

    public static final Codec<ScavengerSavedData> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    Codec.INT.optionalFieldOf("dataVersion", 0).forGetter(ScavengerSavedData::getDataVersion),
                    Identifier.CODEC.fieldOf("itemId").forGetter(ScavengerSavedData::getItemId),
                    Identifier.CODEC.fieldOf("modifier").forGetter(ScavengerSavedData::getModifierId),
                    Codec.BOOL.fieldOf("hasWon").forGetter(ScavengerSavedData::hasWon),
                    Codec.LONG.fieldOf("winTimestamp").forGetter(ScavengerSavedData::getWinTimestamp),
                    Codec.BOOL.optionalFieldOf("speedRulesEnabled", true).forGetter(ScavengerSavedData::isSpeedRulesEnabled),
                    Codec.BOOL.optionalFieldOf("started", false).forGetter(ScavengerSavedData::isStarted),
                    Codec.LONG.optionalFieldOf("startGameTime", -1L).forGetter(ScavengerSavedData::getStartGameTime),
                    Codec.unboundedMap(UUIDUtil.STRING_CODEC, Codec.LONG).optionalFieldOf("hunterFindTimes", Map.of()).forGetter(ScavengerSavedData::getHunterFindTimes),
                    UUIDUtil.CODEC.optionalFieldOf("lastSurvivorUuid").forGetter(ScavengerSavedData::getLastSurvivorUuid),
                    Codec.LONG.optionalFieldOf("lastSurvivorTimestamp", -1L).forGetter(ScavengerSavedData::getLastSurvivorTimestamp),
                    Codec.BOOL.optionalFieldOf("everMultiplayer", false).forGetter(ScavengerSavedData::isEverMultiplayer)
            ).apply(instance, (dataVersion, itemId, modifier, hasWon, winTimestamp, speedRulesEnabled, started, startGameTime, hunterFindTimes, lastSurvivorUuid, lastSurvivorTimestamp, everMultiplayer) -> {
                var data = new ScavengerSavedData(itemId, modifier, hasWon, winTimestamp, speedRulesEnabled, started, startGameTime, hunterFindTimes, lastSurvivorUuid.orElse(null), lastSurvivorTimestamp, everMultiplayer);
                data.dataVersion = dataVersion;
                return data;
            }));

    public static final SavedDataType<ScavengerSavedData> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath(Scavenger.MOD_ID, DATA_NAME),
            ScavengerSavedData::new,
            CODEC,
            DataFixTypes.LEVEL
    );

    public int getDataVersion() {
        return dataVersion;
    }

    public Identifier getItemId() {
        return itemId;
    }
    public Item getItem() {
        return BuiltInRegistries.ITEM.getValue(itemId);
    }

    public void setItem(Item item) {
        this.itemId = BuiltInRegistries.ITEM.getKey(item);

        this.setDirty();
    }

    public long getWinTimestamp() {
        return winTimestamp;
    }

    public void setWinTimestamp(long winTimestamp) {
        this.winTimestamp = winTimestamp;
        this.setDirty();
    }

    public Identifier getModifierId() {
        return modifierId;
    }

    public ScavengerModifier getModifier() {
        return Modifiers.get(modifierId);
    }

    public void setModifierId(Identifier modifierId) {
        this.modifierId = modifierId;

        this.setDirty();
    }

    public boolean hasWon() {
        return hasWon;
    }

    public void win(long winTimestamp) {
        this.hasWon = true;
        this.setWinTimestamp(winTimestamp);
        this.setDirty();
    }

    public boolean isSpeedRulesEnabled() {
        return speedRulesEnabled;
    }

    public boolean isStarted() {
        return started;
    }

    public void setStarted(boolean started) {
        this.started = started;
        this.setDirty();
    }

    public long getStartGameTime() {
        return startGameTime;
    }

    public void setStartGameTime(long startGameTime) {
        this.startGameTime = startGameTime;
        this.setDirty();
    }

    public Map<UUID, Long> getHunterFindTimes() {
        return hunterFindTimes;
    }

    // Whether this player has EVER reached the item threshold - persisted, so it survives a
    // server restart (unlike the old in-memory-only tracking). This is what makes dropping the
    // item after qualifying unable to un-become a hunter, even across relogs/restarts.
    public boolean isHunter(UUID uuid) {
        return hunterFindTimes.containsKey(uuid);
    }

    // The elapsed time (already offset-adjusted, see ScavengerCombat#elapsedGameTime) at which
    // this player personally found the item, or null if they haven't (yet).
    public Long getHunterFindTime(UUID uuid) {
        return hunterFindTimes.get(uuid);
    }

    // Registers a player as a hunter along with the moment they found the item, but only the
    // FIRST time - later calls for the same player are no-ops so their find time can't drift.
    public void registerHunter(UUID uuid, long findTime) {
        if (hunterFindTimes.putIfAbsent(uuid, findTime) == null) {
            this.setDirty();
        }
    }

    public Optional<UUID> getLastSurvivorUuid() {
        return Optional.ofNullable(lastSurvivorUuid);
    }

    public long getLastSurvivorTimestamp() {
        return lastSurvivorTimestamp;
    }

    // Records which hunter was the last one left standing (battle-royale style win) and when,
    // so a rejoining player can be shown this correctly instead of just their item pickup time.
    public void setLastSurvivor(UUID uuid, long timestamp) {
        this.lastSurvivorUuid = uuid;
        this.lastSurvivorTimestamp = timestamp;
        this.setDirty();
    }

    public boolean isEverMultiplayer() {
        return everMultiplayer;
    }

    // Set once, the first time more than one real player is online at the same time - stays true
    // for the rest of the world's life even if everyone but the host later leaves/dies. Used to
    // decide whether things meant for a single challenger (like the hardcore restart button)
    // still make sense to offer.
    public void setEverMultiplayer(boolean everMultiplayer) {
        if (!this.everMultiplayer && everMultiplayer) {
            this.everMultiplayer = true;
            this.setDirty();
        }
    }

    private int dataVersion;
    private Identifier itemId;
    private Identifier modifierId;
    private boolean hasWon;
    private long winTimestamp;
    private boolean speedRulesEnabled;
    private boolean started;
    private long startGameTime;
    private Map<UUID, Long> hunterFindTimes;
    private UUID lastSurvivorUuid;
    private long lastSurvivorTimestamp;
    private boolean everMultiplayer;

    private ScavengerSavedData(Identifier itemId, Identifier modifierId, boolean hasWon, long winTimestamp, boolean speedRulesEnabled, boolean started, long startGameTime, Map<UUID, Long> hunterFindTimes, UUID lastSurvivorUuid, long lastSurvivorTimestamp, boolean everMultiplayer) {
        this.itemId = itemId;
        this.modifierId = modifierId;
        this.hasWon = hasWon;
        this.winTimestamp = winTimestamp;
        this.speedRulesEnabled = speedRulesEnabled;
        this.started = started;
        this.startGameTime = startGameTime;
        this.hunterFindTimes = new HashMap<>(hunterFindTimes);
        this.lastSurvivorUuid = lastSurvivorUuid;
        this.lastSurvivorTimestamp = lastSurvivorTimestamp;
        this.everMultiplayer = everMultiplayer;

        this.setDirty();
    }

    public ScavengerSavedData() {
        this.dataVersion = CURRENT_DATA_VERSION;
        this.itemId = BuiltInRegistries.ITEM.getKey(Scavenger.TEMP_DATA.item);
        this.modifierId = Scavenger.TEMP_DATA.modifier;
        this.hasWon = false;
        this.speedRulesEnabled = Scavenger.TEMP_DATA.speedRulesEnabled;
        this.started = false;
        this.startGameTime = -1L;
        this.hunterFindTimes = new HashMap<>();
        this.lastSurvivorUuid = null;
        this.lastSurvivorTimestamp = -1L;
        this.everMultiplayer = false;

        Scavenger.TEMP_DATA.item = Items.AIR;
        Scavenger.TEMP_DATA.modifier = Modifiers.NONE.getId();
        Scavenger.TEMP_DATA.speedRulesEnabled = true;

        this.setDirty();
    }

    public static ScavengerSavedData get(MinecraftServer server) {
        applyPreLoadMigrations(server);
        ScavengerSavedData data = server.getDataStorage().computeIfAbsent(TYPE);
        data.applyDataMigrations(server);
        return data;
    }

    private static void applyPreLoadMigrations(MinecraftServer server) {
        for (var migration : PRE_LOAD_MIGRATIONS) {
            migration.apply(server);
        }
    }

    private void applyDataMigrations(MinecraftServer server) {
        if (dataVersion >= CURRENT_DATA_VERSION) return;
        while (dataVersion < CURRENT_DATA_VERSION) {
            applyDataMigration(dataVersion, server);
            dataVersion++;
        }
        this.setDirty();
    }

    private void applyDataMigration(int fromVersion, MinecraftServer server) {
        // Add future data migrations here keyed by fromVersion
    }

    private static void migrate_v0_to_v1(MinecraftServer server) {
        Path oldFile = server.getWorldPath(LevelResource.ROOT).resolve("data/scavenger_data.dat");
        Path newDir = server.getWorldPath(LevelResource.DATA).resolve(Scavenger.MOD_ID);
        Path newFile = newDir.resolve("scavenger_data.dat");

        if (!Files.exists(oldFile)) {
            return;
        }

        try {
            Files.createDirectories(newDir);
            Files.move(oldFile, newFile);
        } catch (IOException ignored) {
        }
    }

    @FunctionalInterface
    private interface PreLoadMigration {
        void apply(MinecraftServer server);
    }

    public static Optional<ScavengerSavedData> readFromDisk(Path path) {
        if (!Files.isRegularFile(path)) {
            return Optional.empty();
        }

        try {
            CompoundTag root = NbtIo.readCompressed(path, NbtAccounter.uncompressedQuota());
            CompoundTag data = root.getCompound("data").orElse(root);
            Optional<Identifier> itemId = data.getString("itemId").map(Identifier::tryParse);
            Optional<Identifier> modifierId = data.getString("modifier").map(Identifier::tryParse);

            if (itemId.isEmpty() || modifierId.isEmpty()) {
                return Optional.empty();
            }

            boolean hasWon = data.getBooleanOr("hasWon", false);
            long winTimestamp = data.getLongOr("winTimestamp", 0L);
            boolean speedRulesEnabled = data.getBooleanOr("speedRulesEnabled", true);
            boolean started = data.getBooleanOr("started", false);
            long startGameTime = data.getLongOr("startGameTime", -1L);

            return Optional.of(new ScavengerSavedData(itemId.get(), modifierId.get(), hasWon, winTimestamp, speedRulesEnabled, started, startGameTime, Map.of(), null, -1L, false));
        } catch (IOException exception) {
            return Optional.empty();
        }
    }

    public boolean isEmpty() {
        return this.modifierId.equals(Modifiers.NONE.getId()) && itemId.equals(BuiltInRegistries.ITEM.getKey(Items.AIR));
    }
}
