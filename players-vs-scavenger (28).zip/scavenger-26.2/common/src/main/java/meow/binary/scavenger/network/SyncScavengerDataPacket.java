package meow.binary.scavenger.network;

import it.hurts.shatterbyte.shatterlib.module.network.Packet;
import meow.binary.scavenger.Scavenger;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;

public class SyncScavengerDataPacket extends Packet {
    public static Type<SyncScavengerDataPacket> TYPE = Packet.createType(Scavenger.MOD_ID, "test_screen");
    public static StreamCodec<RegistryFriendlyByteBuf, SyncScavengerDataPacket> STREAM_CODEC = Packet.createCodec(SyncScavengerDataPacket::write, SyncScavengerDataPacket::new);

    public Item getItem() {
        return item;
    }
    public Identifier getModifier() {
        return modifier;
    }
    public long getWinTimestamp() {
        return winTimestamp;
    }
    public long getStartGameTime() {
        return startGameTime;
    }
    public long getLastSurvivorTimestamp() {
        return lastSurvivorTimestamp;
    }
    public boolean isMultiplayer() {
        return multiplayer;
    }

    Item item;
    Identifier modifier;
    long winTimestamp;
    public boolean isWin;
    // Absolute world-time tick the round was /start-ed at (or -1 if never explicitly started).
    // The client subtracts this from the live world time so the on-screen timer counts from
    // zero at /start instead of from world creation - separate from winTimestamp, which is
    // already a final, frozen (and already offset-adjusted) elapsed value.
    long startGameTime;
    // Elapsed time this player became the last hunter standing (or -1 if this win isn't that -
    // e.g. a plain singleplayer/first-to-find win). winTimestamp above stays the original item
    // pickup time either way, so the main Victory screen display never changes; this is shown as
    // an extra line underneath when present.
    long lastSurvivorTimestamp;
    // Whether more than one real player has EVER been online together on this world. Used
    // client-side to hide things meant for a single challenger, like the hardcore restart button.
    boolean multiplayer;

    public SyncScavengerDataPacket(RegistryFriendlyByteBuf buf) {
        super(buf);
        this.item = BuiltInRegistries.ITEM.getValue(buf.readIdentifier());
        this.modifier = buf.readIdentifier();
        this.winTimestamp = buf.readLong();
        this.isWin = buf.readBoolean();
        this.startGameTime = buf.readLong();
        this.lastSurvivorTimestamp = buf.readLong();
        this.multiplayer = buf.readBoolean();
    }

    public SyncScavengerDataPacket(Item item, Identifier modifier, long winTimestamp, boolean isWin, long startGameTime, long lastSurvivorTimestamp, boolean multiplayer) {
        this.item = item;
        this.modifier = modifier;
        this.winTimestamp = winTimestamp;
        this.isWin = isWin;
        this.startGameTime = startGameTime;
        this.lastSurvivorTimestamp = lastSurvivorTimestamp;
        this.multiplayer = multiplayer;
    }

    @Override
    public void write(RegistryFriendlyByteBuf buf) {
        buf.writeIdentifier(BuiltInRegistries.ITEM.getKey(item));
        buf.writeIdentifier(modifier);
        buf.writeLong(winTimestamp);
        buf.writeBoolean(isWin);
        buf.writeLong(startGameTime);
        buf.writeLong(lastSurvivorTimestamp);
        buf.writeBoolean(multiplayer);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
