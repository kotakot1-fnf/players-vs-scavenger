package meow.binary.scavenger.client;

import meow.binary.scavenger.data.modifier.ScavengerModifier;
import meow.binary.scavenger.registry.Modifiers;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

public class ClientScavengerData {
    public static Item item = Items.AIR;
    public static Identifier modifier = Modifiers.NONE.getId();
    public static long winTimestamp = 0L;
    public static long startGameTime = -1L;
    public static long lastSurvivorTimestamp = -1L;
    public static boolean multiplayer = false;

    public static void clear() {
        item = Items.AIR;
        modifier = Modifiers.NONE.getId();
        winTimestamp = 0L;
        startGameTime = -1L;
        lastSurvivorTimestamp = -1L;
        multiplayer = false;
    }

    public static boolean isEmpty() {
        return modifier.equals(Modifiers.NONE.getId()) && item.equals(Items.AIR);
    }

    public static boolean is(ScavengerModifier otherModifier) {
        return modifier.equals(otherModifier.getId());
    }
}
