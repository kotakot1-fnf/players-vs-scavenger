package meow.binary.scavenger.mixin;

import meow.binary.scavenger.client.screen.ScavengerWorldCreateScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import net.minecraft.client.gui.screens.worldselection.WorldCreationUiState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CreateWorldScreen.class)
public abstract class CreateWorldScreenMixin {
    @Shadow
    public abstract void onClose();

    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
   private void openPendingRestart(CallbackInfo ci) {
       if (ScavengerWorldCreateScreen.pendingRunHistory) {
           ScavengerWorldCreateScreen.pendingRunHistory = false;
           this.onClose();
           return;
       }

       if (!ScavengerWorldCreateScreen.hasPendingRestart()) {
           return;
       }

       Minecraft minecraft = Minecraft.getInstance();
       CreateWorldScreen createWorldScreen = (CreateWorldScreen) (Object) this;
       
        ScavengerWorldCreateScreen.PendingRestart restart = ScavengerWorldCreateScreen.consumePendingRestart();
        createWorldScreen.getUiState().setGameMode(restart.hardcore()
                ? WorldCreationUiState.SelectedGameMode.HARDCORE
                : WorldCreationUiState.SelectedGameMode.SURVIVAL);
       minecraft.gui.setScreen(new ScavengerWorldCreateScreen(createWorldScreen, minecraft, restart.item(), restart.modifier(), restart.worldName(), true));
       ci.cancel();
   }

   @Inject(method = "onCreate", at = @At("HEAD"), cancellable = true)
   private void openScavengerWorldCreateScreen(CallbackInfo ci) {
       if (ScavengerWorldCreateScreen.isCreatingVanillaWorld()) {
           return;
       }

       Minecraft minecraft = Minecraft.getInstance();
       CreateWorldScreen createWorldScreen = (CreateWorldScreen) (Object) this;

       // Scavenger is built around permanent death raising the stakes - without Hardcore, dying
       // just means respawning and continuing, which defeats the whole "one shot" premise. So the
       // wheel only shows up for a Hardcore world; anything else creates a plain vanilla world,
       // completely untouched by the mod.
       if (createWorldScreen.getUiState().getGameMode() != WorldCreationUiState.SelectedGameMode.HARDCORE) {
           return;
       }

       minecraft.gui.setScreen(new ScavengerWorldCreateScreen(createWorldScreen, minecraft));
       ci.cancel();
   }
}
