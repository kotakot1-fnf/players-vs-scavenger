package meow.binary.scavenger;

import it.hurts.shatterbyte.shatterlib.module.config.ConfigManager;
import it.hurts.shatterbyte.shatterlib.module.network.ShatterLibNetwork;
import it.hurts.shatterbyte.shatterlib.platform.ShatterLibServices;
import meow.binary.scavenger.client.Config;
import meow.binary.scavenger.combat.ScavengerCombat;
import meow.binary.scavenger.mixin.ServerLevelAccessor;
import meow.binary.scavenger.data.ScavengerSavedData;
import meow.binary.scavenger.data.modifier.ScavengerModifier;
import meow.binary.scavenger.network.SyncRunRecordPacket;
import meow.binary.scavenger.network.SyncScavengerDataPacket;
import meow.binary.scavenger.registry.Modifiers;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.end.EnderDragonFight;

import java.nio.file.Path;
import java.util.Collection;
import java.util.Optional;

public final class Scavenger {
    public static final Config CONFIG = new Config();
    public static final TemporaryData TEMP_DATA = new TemporaryData();
    public static final String MOD_ID = "scavenger";

    public static final Player.BedSleepingProblem INSOMNIA_PROBLEM = new Player.BedSleepingProblem(Component.translatable("scavenger.insomnia"));

    public static final TagKey<Item> VEGETARIAN_FOOD = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, "vegetarian_food"));
    public static final TagKey<Item> UNROLLABLE_BY_DEFAULT = TagKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, "unrollable_by_default"));

    public static void init() {
        ConfigManager.register(MOD_ID, CONFIG);
        CONFIG.load(ShatterLibServices.platform().getConfigDirectory());
        ShatterLibNetwork.registerS2CPayloadType(SyncScavengerDataPacket.TYPE, SyncScavengerDataPacket.STREAM_CODEC);
        ShatterLibNetwork.registerS2CPayloadType(SyncRunRecordPacket.TYPE, SyncRunRecordPacket.STREAM_CODEC);
    }

    public static void onPlayerTick(ServerPlayer serverPlayer) {
        MinecraftServer server = ((ServerLevelAccessor) serverPlayer.level()).scavenger$getServer();
        ScavengerSavedData data = ScavengerSavedData.get(server);
        if (data.isEmpty()) {
            return;
        }

        ScavengerModifier modifier = data.getModifier();

        if (!data.hasWon()) {
            checkWinCondition(serverPlayer, data);
        }

        ScavengerCombat.announceIfNeeded(serverPlayer, data);
        ScavengerCombat.tickTracking(serverPlayer, data);
        ScavengerCombat.tickLobbyFreeze(serverPlayer, data);
        ScavengerCombat.trackMultiplayerStatus(data, server);

        if (modifier.hasPlayerTick()) {
            if (serverPlayer.isSpectator()) {
                revertModifierAttributes(serverPlayer, modifier);
            } else {
                modifier.playerTick(serverPlayer);
            }
        }
    }

    public static void onPlayerJoin(ServerPlayer serverPlayer) {
        // Safety net: if this player disconnected while a Scavenger-applied Slowness/Speed
        // effect was still active (e.g. mid lobby-freeze) and reconnects as a spectator, none of
        // our per-tick systems touch spectators, so a leftover effect would otherwise just sit
        // there unable to move/fly properly until its own duration happens to run out.
        if (serverPlayer.isSpectator()) {
            serverPlayer.removeEffect(MobEffects.SLOWNESS);
            serverPlayer.removeEffect(MobEffects.SPEED);
        }

        MinecraftServer server = ((ServerLevelAccessor) serverPlayer.level()).scavenger$getServer();
        ScavengerSavedData data = ScavengerSavedData.get(server);
        if (data.isEmpty()) return;

        // Resync THIS player's own personal find time (if any) - not the shared winTimestamp,
        // which belongs to whichever player first completed the original race and would show
        // the wrong frozen time for anyone else, or for someone who hasn't found the item at all.
        Long personalFindTime = data.getHunterFindTime(serverPlayer.getUUID());
        long winTimestamp = personalFindTime != null ? personalFindTime : 0L;

        // If this player was the last hunter standing, resync that extra line too.
        boolean isLastSurvivor = data.getLastSurvivorUuid().map(serverPlayer.getUUID()::equals).orElse(false);
        long lastSurvivorTimestamp = isLastSurvivor ? data.getLastSurvivorTimestamp() : -1L;

        SyncScavengerDataPacket packet = new SyncScavengerDataPacket(data.getItem(), data.getModifierId(), winTimestamp, false, data.getStartGameTime(), lastSurvivorTimestamp, data.isEverMultiplayer());
        ShatterLibNetwork.sendToPlayer(serverPlayer, packet);
    }

    public static void onServerLevelLoad(ServerLevel level) {
        ScavengerSavedData data = ScavengerSavedData.get(((ServerLevelAccessor) level).scavenger$getServer());
        if (data.isEmpty()) {
            return;
        }

        ScavengerModifier modifier = data.getModifier();

        if (modifier.hasWorldStart()) {
            modifier.onWorldStart(level);
        }
    }

    // GIANT/TINY/ALIEN/FLAT_FEET set an attribute's base value directly on every tick rather than
    // through a removable modifier, so simply skipping playerTick() for a spectator isn't enough
    // - nothing else would ever set it back. This puts the affected attribute back to its normal
    // default while the player is spectating (which also naturally re-applies the modifier's
    // effect the instant they leave spectator mode again, since playerTick() resumes every tick).
    private static void revertModifierAttributes(ServerPlayer player, ScavengerModifier modifier) {
        if (modifier == Modifiers.GIANT || modifier == Modifiers.TINY) {
            resetAttributeToDefault(player, Attributes.SCALE);
        } else if (modifier == Modifiers.ALIEN) {
            resetAttributeToDefault(player, Attributes.GRAVITY);
        } else if (modifier == Modifiers.FLAT_FEET) {
            resetAttributeToDefault(player, Attributes.JUMP_STRENGTH);
        }
    }

    private static void resetAttributeToDefault(ServerPlayer player, Holder<Attribute> attribute) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance != null) {
            instance.setBaseValue(attribute.value().getDefaultValue());
        }
    }

    private static void checkWinCondition(ServerPlayer player, ScavengerSavedData data) {
        int itemCount = getItemCount(data.getModifierId());

        boolean hasItem = player.getInventory().countItem(data.getItem()) >= itemCount;
        boolean hasWon = hasItem && (!data.getModifierId().equals(Modifiers.FINALIST.getId()) || hasKilledDragon(player));
        if (hasWon) {
            data.win(player.level().getGameTime());
            MinecraftServer server = player.level().getServer();
            server.saveEverything(true, false, false);

            Collection<ServerPlayer> players = server.getPlayerList().getPlayers();
            boolean multiplayer = players.size() > 1;

            // In multiplayer the run doesn't actually end here (PvP keeps going), so the Victory
            // screen - meant for a single, final winner - is skipped entirely. The finder's own
            // HUD timer still gets frozen at their personal time, and everyone else keeps
            // counting until they get there too; both handled per-player by
            // ScavengerCombat.announceIfNeeded(), not here.
            if (!multiplayer) {
                SyncScavengerDataPacket packet = new SyncScavengerDataPacket(data.getItem(), data.getModifierId(), data.getWinTimestamp(), true, data.getStartGameTime(), -1, data.isEverMultiplayer());
                ShatterLibNetwork.sendToPlayers(players, packet);
            }

            SyncRunRecordPacket recordPacket = new SyncRunRecordPacket(
                    server.getWorldData().getLevelName(),
                    data.getItemId(),
                    data.getModifierId(),
                    data.getWinTimestamp(),
                    Optional.of(player.level().getSeed()),
                    multiplayer,
                    false,
                    -1L
            );
            ShatterLibNetwork.sendToPlayers(players, recordPacket);
        }
    }

    private static boolean hasKilledDragon(ServerPlayer player) {
        MinecraftServer server =  player.level().getServer();
        ServerLevel end = server.getLevel(Level.END);
        EnderDragonFight fight = null;

        if (end != null) {
            fight = end.getDragonFight();
        }

        if (fight == null) {
            return false;
        }

        return fight.hasPreviouslyKilledDragon();
    }

    public static int getItemCount(Identifier modifier) {
        int itemCount = 1;
        if (modifier.equals(Modifiers.TWICE.getId())) itemCount = 2;
        else if (modifier.equals(Modifiers.THRICE.getId())) itemCount = 3;

        return itemCount;
    }

    public static boolean isSlotBlocked(int index, Level level) {
        if (Modifiers.isActive(Modifiers.HOLEY_POCKETS, level) && index > 8 && index < 36) {
            return true;
        }

        return false;
    }

    public static void saveConfig() {
        CONFIG.save(ShatterLibServices.platform().getConfigDirectory());
    }
}
