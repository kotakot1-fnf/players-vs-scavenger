package meow.binary.scavenger.combat;

import it.hurts.shatterbyte.shatterlib.ShatterLib;
import it.hurts.shatterbyte.shatterlib.module.network.ShatterLibNetwork;
import meow.binary.scavenger.Scavenger;
import meow.binary.scavenger.client.Config;
import meow.binary.scavenger.client.ScavengerTimeFormat;
import meow.binary.scavenger.data.ScavengerSavedData;
import meow.binary.scavenger.mixin.ServerLevelAccessor;
import meow.binary.scavenger.network.SyncRunRecordPacket;
import meow.binary.scavenger.network.SyncScavengerDataPacket;
import meow.binary.scavenger.registry.Modifiers;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.players.NameAndId;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiPredicate;

/**
 * Implements the "manhunt" style Scavenger PvP rules requested for multiplayer:
 * <ul>
 *     <li>Two players who have BOTH not found the target item can never damage each other.</li>
 *     <li>Any player can damage a player who HAS found the item, but cannot land the killing
 *         blow unless the attacker has found the item too - the item holder is instead left
 *         at minimal health with Blindness + Slowness.</li>
 *     <li>Two players who have BOTH found the item fight like in vanilla Minecraft (normal death).</li>
 *     <li>Any player who has found the item is shown the direction/distance of the closest other
 *         online player, and is slowed down until they get within {@code trackingRange} blocks
 *         of them.</li>
 * </ul>
 * "Found the item" is evaluated dynamically from each player's inventory (item count >= the
 * amount required by the active modifier, e.g. x3 for Thrice/"Тройняшки") rather than the
 * single global {@link ScavengerSavedData#hasWon()} flag, since more than one player can pick
 * up enough copies of the item over the course of a multiplayer game.
 */
public final class ScavengerCombat {
    private ScavengerCombat() {
    }

    // Hunters who have EVER reached the required item count for the currently active item/
    // modifier are persisted directly on ScavengerSavedData now (see data.isHunter/registerHunter)
    // rather than tracked here in memory, so hunter status survives a server restart - dropping
    // the item after qualifying can no longer be used to un-become a hunter.
    // Players who have died at least once this game - used to detect "one player left standing",
    // regardless of whether the ones who died were hunters or not.
    private static final Set<UUID> ELIMINATED_PLAYERS = new HashSet<>();
    // UUIDs of players currently affected by the "mid-range" tracking Slowness or the "far away"
    // tracking Speed, so we only touch the effect when the state actually flips instead of every
    // tick.
    private static final Set<UUID> SLOWED_TRACKERS = new HashSet<>();
    private static final Set<UUID> SPED_UP_TRACKERS = new HashSet<>();
    // Fixed position each frozen player is snapped back to every tick, so the lobby freeze can't
    // be circumvented by jumping (Slowness alone still lets you inch/hop forward over time).
    private static final Map<UUID, Vec3> LOBBY_ANCHORS = new HashMap<>();

    private static boolean battleRoyaleWinnerAnnounced;

    // Identity (not value!) of the last ScavengerSavedData we've seen. Used to detect a genuinely
    // new game/world - comparing item/modifier VALUES was wrong, since picking the same item and
    // modifier again in a new world (easy to do when repeatedly testing) looked identical to the
    // previous world and left all the sticky per-player state from the old game in place.
    private static ScavengerSavedData lastData;

    public static boolean hasItem(ServerPlayer player, ScavengerSavedData data) {
        int required = Scavenger.getItemCount(data.getModifierId());
        return player.getInventory().countItem(data.getItem()) >= required;
    }

    /**
     * Whether this player counts as a hunter for PvP purposes. Unlike {@link #hasItem}, this is
     * STICKY: once a player has reached the required item count at least once, this keeps
     * returning true even if they later drop/lose the item, so dropping it can't be used to
     * escape the PvP rules or the "who can be finished off" protection.
     * Read-only on purpose - registering a player as a hunter happens ONLY in
     * {@link #announceIfNeeded}. If this method registered too (as it briefly used to), calling
     * it for one player (e.g. while checking "has everyone found it" for player A) could silently
     * mark a DIFFERENT player B as already-a-hunter before B's own announceIfNeeded runs this
     * tick, making B's "just became a hunter" edge-trigger never fire.
     */
    public static boolean isHunter(ServerPlayer player, ScavengerSavedData data) {
        return data.isHunter(player.getUUID()) || hasItem(player, data);
    }

    private static ServerPlayer attackerOf(DamageSource source) {
        Entity direct = source.getEntity();
        if (direct instanceof ServerPlayer player) {
            return player;
        }
        return null;
    }

    /**
     * Hook for {@code ServerLivingEntityEvents.ALLOW_DAMAGE}. Returning false fully blocks the
     * hit (no damage, no knockback) - used to stop two item-less players from fighting at all.
     */
    public static boolean allowDamage(LivingEntity victim, DamageSource source, float amount) {
        if (!(victim instanceof ServerPlayer serverVictim)) {
            return true;
        }

        Config.PvpCategory pvpConfig = Scavenger.CONFIG.pvp;
        if (!pvpConfig.enabled) {
            return true;
        }

        ServerPlayer attacker = attackerOf(source);
        if (attacker == null || attacker == serverVictim) {
            return true;
        }

        MinecraftServer server = ((ServerLevelAccessor) serverVictim.level()).scavenger$getServer();
        ScavengerSavedData data = ScavengerSavedData.get(server);
        if (data.isEmpty()) {
            return true;
        }

        boolean attackerHasItem = isHunter(attacker, data);
        boolean victimHasItem = isHunter(serverVictim, data);

        if (!attackerHasItem && !victimHasItem) {
            sendActionBar(attacker, Component.translatable("scavenger.pvp.blocked_attack").withStyle(ChatFormatting.GRAY));
            return false;
        }

        return true;
    }

    /**
     * Hook for {@code ServerLivingEntityEvents.ALLOW_DEATH}. Returning false prevents the kill;
     * the caller is responsible for making sure the entity doesn't stay at non-positive health, which we
     * do here by clamping health up and applying the "spared" debuff.
     */
    public static boolean allowDeath(LivingEntity victim, DamageSource source, float amount) {
        if (!(victim instanceof ServerPlayer serverVictim)) {
            return true;
        }

        Config.PvpCategory pvpConfig = Scavenger.CONFIG.pvp;
        if (!pvpConfig.enabled) {
            return true;
        }

        ServerPlayer attacker = attackerOf(source);
        if (attacker == null || attacker == serverVictim) {
            return true;
        }

        MinecraftServer server = ((ServerLevelAccessor) serverVictim.level()).scavenger$getServer();
        ScavengerSavedData data = ScavengerSavedData.get(server);
        if (data.isEmpty()) {
            return true;
        }

        boolean attackerHasItem = isHunter(attacker, data);
        boolean victimHasItem = isHunter(serverVictim, data);

        // Only the "attacker has NOT found it, victim HAS found it" case is protected.
        // Both empowered, or attacker empowered -> normal vanilla death rules apply.
        if (!victimHasItem || attackerHasItem) {
            return true;
        }

        boolean alreadySpared = serverVictim.hasEffect(MobEffects.BLINDNESS);

        serverVictim.setHealth(Math.max(pvpConfig.protectedMinHealth, 0.5f));
        serverVictim.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, pvpConfig.protectedBlindnessSeconds * 20, 0));
        serverVictim.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, pvpConfig.protectedSlownessSeconds * 20, pvpConfig.protectedSlownessAmplifier));

        if (!alreadySpared) {
            server.getPlayerList().broadcastSystemMessage(
                    Component.translatable("scavenger.pvp.spared", serverVictim.getDisplayName(), attacker.getDisplayName())
                            .withStyle(ChatFormatting.GOLD),
                    false
            );
        }

        return false;
    }

    /**
     * Called every player tick from {@link Scavenger#onPlayerTick(ServerPlayer)}. The moment a
     * player permanently becomes a hunter (see {@link #isHunter}), this broadcasts a chat message
     * and freezes that ONE player's own HUD timer (everyone else's timer keeps running until they
     * individually reach the item too).
     */
    public static void announceIfNeeded(ServerPlayer player, ScavengerSavedData data) {
        if (data.isEmpty()) {
            return;
        }

        resetTrackingStateIfGameChanged(data);

        boolean wasHunterBefore = data.isHunter(player.getUUID());
        boolean hasItemNow = hasItem(player, data);

        if (!hasItemNow || wasHunterBefore) {
            return;
        }

        long elapsedTicks = elapsedGameTime(player, data);
        data.registerHunter(player.getUUID(), elapsedTicks);

        // Covers the reverse order from onPlayerDeath's own check: if everyone else already died
        // before this player found the item, they become "last standing" right here instead of
        // at a death event.
        checkLastPlayerStanding(data, ((ServerLevelAccessor) player.level()).scavenger$getServer());

        try {
            MutableComponent itemName = Component.translatable(data.getItem().getDescriptionId());
            MutableComponent modifierName = Modifiers.getName(data.getModifierId());
            int required = Scavenger.getItemCount(data.getModifierId());
            String time = ScavengerTimeFormat.format(elapsedTicks, data.getModifierId(), false);

            ((ServerLevelAccessor) player.level()).scavenger$getServer().getPlayerList().broadcastSystemMessage(
                    Component.translatable("scavenger.pvp.found_item", time, player.getDisplayName(), itemName, modifierName, required)
                            .withStyle(ChatFormatting.YELLOW),
                    false
            );

            // isWin=false on purpose: this only freezes THIS player's own HUD timer at their
            // personal find time (ClientScavengerData.winTimestamp is client-local), it never
            // shows the Victory screen. Every other connected player keeps counting.
            SyncScavengerDataPacket personalTimerPacket = new SyncScavengerDataPacket(data.getItem(), data.getModifierId(), elapsedTicks, false, data.getStartGameTime(), -1, data.isEverMultiplayer());
            ShatterLibNetwork.sendToPlayer(player, personalTimerPacket);
        } catch (Exception exception) {
            // If this ever throws, the player is already registered as a hunter above (that's
            // persisted, so it's safe), we'd otherwise silently never retry the chat/packet part.
            // Logging it means a bug here shows up in the server log instead of just looking like
            // "nothing happened".
            ShatterLib.LOGGER.warn("Scavenger PvP: failed to announce/freeze timer for {}", player.getName().getString(), exception);
        }
    }

    /**
     * Called every player tick. A hunter far from everyone else gets a Speed boost to close the
     * gap; once within {@code farRange} they're slowed instead (so they can't just speed-rush the
     * whole way in); within {@code trackingRange} both effects lift and they're at normal speed
     * for the actual chase/fight. Skipped entirely if this world's speed rules were turned off on
     * the create-world screen.
     */
    public static void tickTracking(ServerPlayer player, ScavengerSavedData data) {
        Config.PvpCategory pvpConfig = Scavenger.CONFIG.pvp;
        if (!pvpConfig.enabled || data.isEmpty() || !data.isSpeedRulesEnabled() || player.isSpectator() || !isHunter(player, data)) {
            clearTrackingEffects(player);
            return;
        }

        MinecraftServer server = ((ServerLevelAccessor) player.level()).scavenger$getServer();

        if (!pvpConfig.keepSpeedRulesAfterEveryoneFound && allOnlinePlayersAreHunters(server, data)) {
            clearTrackingEffects(player);
            return;
        }

        ServerPlayer nearest = null;
        double nearestDistSq = Double.MAX_VALUE;
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            if (other == player || other.level() != player.level() || other.isSpectator()) {
                continue;
            }
            double distSq = other.distanceToSqr(player);
            if (distSq < nearestDistSq) {
                nearestDistSq = distSq;
                nearest = other;
            }
        }

        if (nearest == null) {
            clearTrackingEffects(player);
            return;
        }

        double distance = Math.sqrt(nearestDistSq);
        UUID uuid = player.getUUID();

        // Durations are kept short and re-applied every tick so effects disappear quickly once
        // the player crosses a threshold, instead of lingering for their full nominal duration.
        if (distance > pvpConfig.farRange) {
            player.addEffect(new MobEffectInstance(MobEffects.SPEED, 60, pvpConfig.farSpeedAmplifier));
            SPED_UP_TRACKERS.add(uuid);
            if (SLOWED_TRACKERS.remove(uuid)) {
                player.removeEffect(MobEffects.SLOWNESS);
            }
        } else if (distance >= pvpConfig.trackingRange) {
            player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, pvpConfig.trackingSlownessAmplifier));
            SLOWED_TRACKERS.add(uuid);
            if (SPED_UP_TRACKERS.remove(uuid)) {
                player.removeEffect(MobEffects.SPEED);
            }
        } else {
            clearTrackingEffects(player);
        }

        sendActionBar(player, Component.translatable(
                "scavenger.pvp.tracking",
                nearest.getDisplayName(),
                bearingArrow(player, nearest),
                Math.round(distance)
        ).withStyle(ChatFormatting.AQUA));
    }

    private static void clearTrackingEffects(ServerPlayer player) {
        UUID uuid = player.getUUID();
        if (SLOWED_TRACKERS.remove(uuid)) {
            player.removeEffect(MobEffects.SLOWNESS);
        }
        if (SPED_UP_TRACKERS.remove(uuid)) {
            player.removeEffect(MobEffects.SPEED);
        }
    }

    // True once every currently-connected, non-spectator player is a hunter - at that point
    // there's no one left to track/be tracked, so the Speed/Slowness rules turn themselves off
    // (unless pvp.keepSpeedRulesAfterEveryoneFound overrides that).
    private static boolean allOnlinePlayersAreHunters(MinecraftServer server, ScavengerSavedData data) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.isSpectator()) {
                continue;
            }
            if (!isHunter(player, data)) {
                return false;
            }
        }
        return true;
    }

    // displayClientMessage(Component, boolean) doesn't exist on this Minecraft version anymore,
    // so the action bar text packet is sent directly - this is a much lower-level, more stable
    // part of the protocol than the removed convenience method.
    private static void sendActionBar(ServerPlayer player, Component message) {
        player.connection.send(new ClientboundSetActionBarTextPacket(message));
    }

    /**
     * Called every player tick. While this world is open to the network - a dedicated server, or
     * a singleplayer world with "Open to LAN" active, even with nobody else connected yet - and
     * the host hasn't run /start (or /st), everyone is pinned in place (position snapped back
     * every tick, so jumping can't inch them forward) and mining is blocked separately in
     * {@link #allowBlockBreak}. Does nothing in plain, unshared singleplayer.
     */
    public static void tickLobbyFreeze(ServerPlayer player, ScavengerSavedData data) {
        UUID uuid = player.getUUID();

        if (data.isEmpty() || data.isStarted() || player.isSpectator()) {
            LOBBY_ANCHORS.remove(uuid);
            if (player.isSpectator()) {
                player.removeEffect(MobEffects.SLOWNESS);
            }
            return;
        }

        MinecraftServer server = ((ServerLevelAccessor) player.level()).scavenger$getServer();
        if (!isMultiplayerContext(server)) {
            LOBBY_ANCHORS.remove(uuid);
            return;
        }

        freezeTimeIfNeeded(server);

        Vec3 anchor = LOBBY_ANCHORS.computeIfAbsent(uuid, ignored -> player.position());
        if (player.position().distanceToSqr(anchor) > 0.01) {
            player.setPos(anchor.x, anchor.y, anchor.z);
        }

        player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 9));

        if (canStartGame(player, server)) {
            sendActionBar(player, Component.translatable("scavenger.pvp.start.hint").withStyle(ChatFormatting.GOLD));
        } else {
            sendActionBar(player, Component.translatable("scavenger.pvp.start.waiting").withStyle(ChatFormatting.GRAY));
        }
    }

    /**
     * Hook for Fabric's {@code PlayerBlockBreakEvents.BEFORE}. Blocks mining entirely while the
     * lobby above is active, so players can't gather a head start before /start is run.
     */
    public static boolean allowBlockBreak(ServerPlayer player) {
        MinecraftServer server = ((ServerLevelAccessor) player.level()).scavenger$getServer();
        ScavengerSavedData data = ScavengerSavedData.get(server);
        return data.isEmpty() || data.isStarted() || !isMultiplayerContext(server);
    }

    // A dedicated server is always "shared". A singleplayer world only counts once "Open to LAN"
    // has actually been used - checked even with just the host connected, so the freeze kicks in
    // right away instead of waiting for a second player to show up.
    // A dedicated server is always "shared". A singleplayer world only counts once "Open to LAN"
    // has actually been used - checked even with just the host connected, so the freeze kicks in
    // right away instead of waiting for a second player to show up.
    // Reflection on purpose: IntegratedServer#isPublished() is a real, long-standing vanilla
    // method, but which package IntegratedServer itself lives in has moved around between
    // versions and isn't worth chasing again - the method name is far more stable than the path.
    private static boolean isMultiplayerContext(MinecraftServer server) {
        if (server.isDedicatedServer()) {
            return true;
        }
        try {
            Object published = server.getClass().getMethod("isPublished").invoke(server);
            return published instanceof Boolean bool && bool;
        } catch (ReflectiveOperationException exception) {
            return false;
        }
    }

    // Stops day/night from advancing while everyone's stuck waiting in the lobby - otherwise a
    // slow-to-gather group could easily burn through 10+ minutes and find themselves starting the
    // actual hunt at night. Goes through the /time command itself rather than any direct
    // day-time API: this version replaced the old single dayTime long with a whole registry of
    // "world clocks"/"timelines" (Registries.WORLD_CLOCK, ClockManager, etc.), which isn't worth
    // reverse-engineering when the command interface on top of it is guaranteed to still work.
    private static void freezeTimeIfNeeded(MinecraftServer server) {
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), "time set 1000");
    }

    /**
     * Called every player tick. The moment more than one real player is online together (a real
     * signal that people actually played together, unlike isMultiplayerContext which is true the
     * instant LAN is opened even with nobody else connected), this is recorded permanently on
     * ScavengerSavedData and every connected client is told right away, so things meant only for
     * a single challenger - like the hardcore death screen's restart button - can hide themselves.
     */
    public static void trackMultiplayerStatus(ScavengerSavedData data, MinecraftServer server) {
        if (data.isEmpty() || data.isEverMultiplayer() || server.getPlayerList().getPlayerCount() <= 1) {
            return;
        }

        data.setEverMultiplayer(true);

        SyncScavengerDataPacket packet = new SyncScavengerDataPacket(data.getItem(), data.getModifierId(), data.getWinTimestamp(), false, data.getStartGameTime(), data.getLastSurvivorTimestamp(), true);
        ShatterLibNetwork.sendToPlayers(server.getPlayerList().getPlayers(), packet);
    }

    // Who's allowed to run /start (or /st) and who sees the "type /start" hint: anyone OP'd
    // (permission level 2+), or - for a singleplayer world opened to LAN - the world's own
    // owner, who has no /op entry but is still meant to be in charge of it.
    // The "is OP" part is deliberately NOT checked here: this class lives in the common module,
    // shared between loaders, and can't depend on any one loader's permission API directly. Each
    // loader's entrypoint (e.g. ScavengerFabric) wires opChecker to its own permission system on
    // startup; it defaults to "nobody" so nothing breaks if a loader forgets to set it.
    public static BiPredicate<ServerPlayer, MinecraftServer> opChecker = (player, server) -> false;

    public static boolean isOwner(ServerPlayer player, MinecraftServer server) {
        return server.isSingleplayerOwner(new NameAndId(player.getGameProfile()));
    }

    private static boolean canStartGame(ServerPlayer player, MinecraftServer server) {
        return opChecker.test(player, server) || isOwner(player, server);
    }

    // Elapsed time to show in chat/HUD. If the game has been explicitly /start-ed, this counts
    // from that moment (so lobby-waiting time - or however long the host played solo before
    // opening to LAN - doesn't inflate everyone's "found at" times); otherwise it falls back to
    // raw world time, matching the original single-player timer.
    private static long elapsedGameTime(ServerPlayer player, ScavengerSavedData data) {
        long current = player.level().getGameTime();
        if (data.isStarted() && data.getStartGameTime() >= 0) {
            return Math.max(0, current - data.getStartGameTime());
        }
        return current;
    }

    /**
     * Executes {@code /start} or {@code /st}. Registered from the Fabric entrypoint with a
     * permission check on {@code .requires(...)}, so this itself doesn't need to re-check them.
     */
    public static int executeStart(CommandSourceStack source) {
        MinecraftServer server = source.getServer();
        ScavengerSavedData data = ScavengerSavedData.get(server);

        if (data.isEmpty()) {
            source.sendFailure(Component.translatable("scavenger.pvp.start.no_game"));
            return 0;
        }
        if (data.isStarted()) {
            source.sendFailure(Component.translatable("scavenger.pvp.start.already_started"));
            return 0;
        }

        data.setStarted(true);
        data.setStartGameTime(source.getLevel().getGameTime());
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.removeEffect(MobEffects.SLOWNESS);
        }

        // Resets everyone's on-screen timer to start counting from zero right now, instead of
        // from world creation (isWin=false, so this doesn't freeze anything or pop the Victory
        // screen - the running HUD timer just gets its zero-point moved to this instant).
        SyncScavengerDataPacket resetPacket = new SyncScavengerDataPacket(data.getItem(), data.getModifierId(), 0, false, data.getStartGameTime(), -1, data.isEverMultiplayer());
        ShatterLibNetwork.sendToPlayers(server.getPlayerList().getPlayers(), resetPacket);

        server.getPlayerList().broadcastSystemMessage(
                Component.translatable("scavenger.pvp.start.started").withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD),
                false
        );
        return 1;
    }

    /**
     * Hook for {@code ServerLivingEntityEvents.AFTER_DEATH}. Broadcasts who died (and who killed
     * them, if it was another player) along with the elapsed run time, so multiplayer games have
     * a record of "who died when" even without the (now multiplayer-disabled) Victory screen.
     * Also checks whether this death leaves exactly one player standing.
     */
    public static void onPlayerDeath(LivingEntity entity, DamageSource source) {
        if (!(entity instanceof ServerPlayer victim)) {
            return;
        }

        MinecraftServer server = ((ServerLevelAccessor) victim.level()).scavenger$getServer();
        ScavengerSavedData data = ScavengerSavedData.get(server);
        if (data.isEmpty()) {
            return;
        }

        String time = ScavengerTimeFormat.format(elapsedGameTime(victim, data), data.getModifierId(), false);
        ServerPlayer killer = attackerOf(source);

        MutableComponent message;
        if (killer != null && killer != victim) {
            message = Component.translatable("scavenger.pvp.death.killed", time, victim.getDisplayName(), killer.getDisplayName());
        } else {
            message = Component.translatable("scavenger.pvp.death.other", time, victim.getDisplayName());
        }

        server.getPlayerList().broadcastSystemMessage(message.withStyle(ChatFormatting.DARK_RED), false);

        // Any death counts here, not just a hunter's - the last player left standing might have
        // been the only one who ever found the item while everyone else died to mobs, hazards,
        // etc without ever becoming hunters themselves.
        ELIMINATED_PLAYERS.add(victim.getUUID());
        checkLastPlayerStanding(data, server);
    }

    /**
     * Checks whether exactly one non-spectator player is currently online and hasn't died yet,
     * and that player is a hunter - if so, they get the Victory screen (isWin=true), same as a
     * singleplayer win. Requires at least one other player to have died at some point (so this
     * can't fire in plain singleplayer, or the instant a lone player finds the item before anyone
     * else has been eliminated). Called both after any death and right when a player newly
     * becomes a hunter, since either order can be the one that leaves them last standing.
     */
    private static void checkLastPlayerStanding(ScavengerSavedData data, MinecraftServer server) {
        if (battleRoyaleWinnerAnnounced || ELIMINATED_PLAYERS.isEmpty()) {
            return;
        }

        ServerPlayer survivor = null;
        int remaining = 0;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.isSpectator() || ELIMINATED_PLAYERS.contains(player.getUUID())) {
                continue;
            }
            remaining++;
            survivor = player;
        }

        if (remaining != 1 || !isHunter(survivor, data)) {
            return;
        }

        battleRoyaleWinnerAnnounced = true;

        long survivalTime = elapsedGameTime(survivor, data);
        data.setLastSurvivor(survivor.getUUID(), survivalTime);

        // winTimestamp stays the winner's ORIGINAL item pickup time (like a normal win), so the
        // main Victory screen display doesn't change; survivalTime rides along separately so the
        // screen can show an extra "last one standing at" line underneath.
        Long personalFindTime = data.getHunterFindTime(survivor.getUUID());
        long pickupTime = personalFindTime != null ? personalFindTime : survivalTime;

        SyncScavengerDataPacket packet = new SyncScavengerDataPacket(data.getItem(), data.getModifierId(), pickupTime, true, data.getStartGameTime(), survivalTime, data.isEverMultiplayer());
        ShatterLibNetwork.sendToPlayer(survivor, packet);

        // Also records this into the run history table (only ever reachable in multiplayer,
        // since it requires at least one other player to have died) so it shows up alongside
        // normal runs, marked as a last-player-standing win rather than a plain first-to-find one.
        SyncRunRecordPacket recordPacket = new SyncRunRecordPacket(
                server.getWorldData().getLevelName(),
                data.getItemId(),
                data.getModifierId(),
                pickupTime,
                Optional.of(survivor.level().getSeed()),
                true,
                true,
                survivalTime
        );
        ShatterLibNetwork.sendToPlayer(survivor, recordPacket);

        server.getPlayerList().broadcastSystemMessage(
                Component.translatable("scavenger.pvp.battle_royale_winner", survivor.getDisplayName())
                        .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                false
        );
    }

    private static void resetTrackingStateIfGameChanged(ScavengerSavedData data) {
        if (data == lastData) {
            return;
        }

        ELIMINATED_PLAYERS.clear();
        SLOWED_TRACKERS.clear();
        SPED_UP_TRACKERS.clear();
        battleRoyaleWinnerAnnounced = false;
        lastData = data;
    }

    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};

    // Arrow pointing towards "to", relative to where "from" is currently looking - so "up" means
    // "walk straight ahead", "right" means "turn right", etc., and it rotates as the player turns
    // (previous version was relative to world north/south/east/west, which doesn't rotate with
    // the camera and reads as broken/random to a player who doesn't track compass directions).
    private static String bearingArrow(ServerPlayer from, ServerPlayer to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double relativeYaw = targetYaw - from.getYRot();
        int index = (int) Math.floor(((relativeYaw % 360) + 360) % 360 / 45.0 + 0.5) % 8;
        return ARROWS[index];
    }
}
