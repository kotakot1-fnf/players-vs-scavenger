package meow.binary.scavenger.mixin.modifier;

import meow.binary.scavenger.client.ClientScavengerData;
import meow.binary.scavenger.mixin.OptionsSubScreenAccessor;
import meow.binary.scavenger.registry.Modifiers;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.options.VideoSettingsScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(VideoSettingsScreen.class)
public class VideoSettingsScreenMixin {
    // Mirrors MouseSettingsScreenMixin's approach for DRUNK's mouse-invert lock: the FOV value
    // itself is forced by ScavengerClient#enforceMinimumFov (a stored option, not something faked
    // at render time), this just grays out the slider so the player can't drag it back up.
    @Inject(method = "addOptions", at = @At("TAIL"))
    private void disableFovSlider(CallbackInfo ci) {
        if (!ClientScavengerData.is(Modifiers.BLINDERS)) {
            return;
        }

        OptionsSubScreenAccessor accessor = (OptionsSubScreenAccessor) this;
        AbstractWidget fovWidget = accessor.getList().findOption(accessor.getOptions().fov());
        if (fovWidget != null) {
            fovWidget.active = false;
        }
    }
}
