package meow.binary.scavenger.fabric;

import it.hurts.shatterbyte.shatterlib.fabric.FabricPlatformHelper;
import it.hurts.shatterbyte.shatterlib.platform.ShatterLibServices;
import meow.binary.scavenger.Scavenger;
import meow.binary.scavenger.combat.ScavengerCombat;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLevelEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.permission.v1.PermissionPredicates;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.PermissionLevel;

public final class ScavengerFabric implements ModInitializer {
    // Fabric API's own permission abstraction (fabric-permissions-api) rather than vanilla's
    // internal permission-check plumbing directly, since the latter keeps getting restructured
    // between versions - defaults to "OP level 2", but also lets a permission-provider mod
    // (LuckPerms etc, if the server has one) grant the scavenger:start node to non-op players.
    // This has to live here (not in the common module) since it's Fabric API specific.
    private static final Identifier START_PERMISSION = Identifier.fromNamespaceAndPath(Scavenger.MOD_ID, "start");

    @Override
    public void onInitialize() {
        ShatterLibServices.initialize(FabricPlatformHelper.INSTANCE);
        Scavenger.init();

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            Scavenger.onPlayerJoin((ServerPlayer) handler.getPlayer());
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                Scavenger.onPlayerTick(player);
            }
        });

        ServerLevelEvents.LOAD.register((server, world) -> {
            Scavenger.onServerLevelLoad(world);
        });

        // Manhunt-style PvP: blocks fights between two players who haven't found the item,
        // and protects a player who HAS found it from being finished off by one who hasn't.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(ScavengerCombat::allowDamage);
        ServerLivingEntityEvents.ALLOW_DEATH.register(ScavengerCombat::allowDeath);
        ServerLivingEntityEvents.AFTER_DEATH.register(ScavengerCombat::onPlayerDeath);

        // Lobby: nobody can mine until the host runs /start or /st, when the world is shared.
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) ->
                !(player instanceof ServerPlayer serverPlayer) || ScavengerCombat.allowBlockBreak(serverPlayer));

        // Lets ScavengerCombat's (loader-agnostic) lobby hint know who's OP without the common
        // module having to depend on any one loader's permission API.
        ScavengerCombat.opChecker = (player, server) -> player.checkPermission(START_PERMISSION, PermissionLevel.GAMEMASTERS);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(Commands.literal("start")
                    .requires(ScavengerFabric::canRunStartCommand)
                    .executes(context -> ScavengerCombat.executeStart(context.getSource())));
            dispatcher.register(Commands.literal("st")
                    .requires(ScavengerFabric::canRunStartCommand)
                    .executes(context -> ScavengerCombat.executeStart(context.getSource())));
        });
    }

    private static boolean canRunStartCommand(CommandSourceStack source) {
        if (PermissionPredicates.<CommandSourceStack>require(START_PERMISSION, PermissionLevel.GAMEMASTERS).test(source)) {
            return true;
        }
        return source.getEntity() instanceof ServerPlayer player && ScavengerCombat.isOwner(player, source.getServer());
    }
}
